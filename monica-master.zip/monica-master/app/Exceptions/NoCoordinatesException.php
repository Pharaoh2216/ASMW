<?php

namespace App\Exceptions;

use RuntimeException;

class NoCoordinatesException extends RuntimeException
{
}
