<?php

namespace App\Exceptions;

use RuntimeException;

/**
 * Exception thrown by Stripe.
 */
class StripeException extends RuntimeException
{
}
