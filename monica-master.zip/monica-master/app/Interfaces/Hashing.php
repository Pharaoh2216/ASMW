<?php

namespace App\Interfaces;

interface Hashing
{
    public function hashID();
}
