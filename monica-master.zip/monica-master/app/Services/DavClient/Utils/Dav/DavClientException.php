<?php

namespace App\Services\DavClient\Utils\Dav;

use Exception;

class DavClientException extends Exception
{
}
