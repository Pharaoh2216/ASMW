<?php

namespace App\Services\DavClient\Utils\Dav;

class DavServerNotCompliantException extends DavClientException
{
}
