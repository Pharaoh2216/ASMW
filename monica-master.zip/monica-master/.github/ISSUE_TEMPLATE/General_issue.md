---
name: Feedback
about: If you want to leave a general comment

---

(Note: you don't need to follow this template, nor to keep headlines or bold sentences - they are just there to guide you. Feel free to delete everything. We review every issue even if we don't immediately respond.)

Thanks for filing an issue and for your interest in the project.

If your issue is about a feature request, tell us why you need it.

If your issue is about a bug, please be as precise as possible in describing it.