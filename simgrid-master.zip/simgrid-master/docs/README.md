If you are browsing these files in the source archive, your probably
want to read the online documentation: https://simgrid.org/doc/latest/

This directory only contains the source files to build the documentation.